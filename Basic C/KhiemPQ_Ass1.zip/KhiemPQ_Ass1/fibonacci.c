/*******************************************************************************
* Includes
******************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "fibonacci.h"
/*******************************************************************************
* Code
******************************************************************************/
int32_t max(int32_t number1, int32_t number2)
{
	int32_t max;
	if(number1 > number2)
	{
		max = number1;
    }
	else
	{
		max = number2;
	}
	return max;
}

void fibonacci(int32_t count)
{
	int32_t index;
	int32_t check = 0; /* Using to check overflow */
	while (count--)
	{
		for (index = 0; index < max(fbnc_1.val, fbnc_2.val); index++)
		{
			fbnc_temp.fbnc[index] = (fbnc_1.fbnc[index] + fbnc_2.fbnc[index] + check) % 10;
			check = (fbnc_1.fbnc[index] + fbnc_2.fbnc[index] + check) / 10;
		}

		if (index == max(fbnc_1.val, fbnc_2.val) && check == 1)
		{
			fbnc_temp.fbnc[index] = 1;
			fbnc_temp.val = index + 1;
		} else
		{
			fbnc_temp.val = index;
		}

		fbnc_2 = fbnc_1;
		fbnc_1 = fbnc_temp;
		check = 0;

		if(count == 0) /* Show value of Fibonacci of number */
		{
            for (index = fbnc_temp.val - 1; index >= 0; index--)
            {
                printf("%d", fbnc_temp.fbnc[index]);	
			}
        }
	}
}
/*******************************************************************************
* End of file
******************************************************************************/
