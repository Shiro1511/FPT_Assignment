#ifndef _FIBONACCI_H_
#define _FIBONACCI_H_

struct fbnc {
	int32_t fbnc[50];
	int32_t val;
} fbnc_1, fbnc_2, fbnc_temp;

int32_t max(int32_t number1, int32_t number2); /* Function compare number 1 and number2 */

void fibonacci(int32_t count);

#endif /* _FIBONACCI_H_ */
