/*******************************************************************************
* Includes
******************************************************************************/
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "fibonacci.h"
/*******************************************************************************
* Code
******************************************************************************/
int32_t main()
{
    int32_t g_number;
    fbnc_1.fbnc[0] = 1;
    fbnc_2.fbnc[0] = 1;
    fbnc_1.val = 1;
    fbnc_2.val = 1;

	printf("Enter the number of Fibonacci Numbers (1 <= number <= 100): ");
    scanf("%d", &g_number);

    while (g_number < 1 || g_number > 100)
    {
        printf("Please enter the number of Fibonacci Numbers (1 <= number <= 100): ");
		scanf("%d", &g_number);
    }

	switch (g_number)
    {
    case 1:
        printf("Fibonacci: 1");
        break;
    case 2:
        printf("Fibonacci: 1");
        break;
    default:
        printf("Fibonacci: ");
	    fibonacci(g_number - 2);
        break;
    }
	return 0;
}/*******************************************************************************
* End of file
******************************************************************************/
