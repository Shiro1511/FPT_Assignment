/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "function.h"
/*******************************************************************************
 * Functions
 ******************************************************************************/
uint8_t Menu()
{
	uint8_t choose;
	printf("\nProgram to manage numbers with arrays.");
	printf("\nEnter 'c' to clear data of old array and enter new array.");
	printf("\nEnter 'p' to print the array.");
	printf("\nEnter 'i' to add an element to the array with position k.");
	printf("\nEnter 'd' to delete an element at position k.");
	printf("\nEnter 's' to print the array sorted in ascending order.");
	printf("\nEnter 'x' to print the array sorted in descending order.");
	printf("\nEnter 't' to find if x is in the array.");
	printf("\nEnter 'a' to print to the screen the biggest number.");
	printf("\nEnter 'w' to print to the screen the smallest number.");
	printf("\nEnter 'e' to exit the program.");
	printf("\nPlease enter you selection: ");
	scanf(" %c", &choose);
	return choose;
}

void enter()
{
	printf("\nEnter the number of elements: ");
	scanf("%d", &number);
	printf("Enter new array: \n");
	for (myIndex = 0; myIndex < number; myIndex++)
	{
		scanf("%d", &arr[myIndex]);
	}
}

uint32_t checkEmpty(uint32_t arr[])
{
	uint32_t len = sizeof(arr)/sizeof(arr[0]);
	uint32_t count = 0;
	for(myIndex = 0; myIndex < len; myIndex++)
	{
		if(arr[myIndex] != 0)
		{
			count++;
		}
	}
	
    if(count != 0)
	{
		return 0;
    }
    else
    {
    	return 1;
	}
}

void print()
{
	if( checkEmpty(arr) == 0)
	{
		printf("\nArray\n");
		for (myIndex = 0; myIndex < number; myIndex++)
		{
			printf("%d ", arr[myIndex]);
  		}
  	}
  	else
	{
		printf("Array is empty!");
	}
    printf("\n");
}

void clear()
{
	memset(arr,0, sizeof(arr)/sizeof(arr[0])); /* Use to clear array */
	print(); 
}

void add()
{
	printf("\nEnter the value you want to insert: ");
	scanf("%d", &value);
	printf("Enter the position: ");
	scanf("%d", &pos);
	for (myIndex = number + 1; myIndex >= pos; myIndex--)
	{
		arr[myIndex] = arr[myIndex - 1];
	}
	
	arr[pos - 1] = value;
	printf("\nNew array we get is:\n");
	for (myIndex = 0; myIndex < number + 1; myIndex++)
	{
		printf("%d ", arr[myIndex]);
	}
	printf("\n");
}

void erease()
{
	uint32_t count = 0;
	printf("\nEnter the position: ");
	scanf("%d", &pos);
	for(myIndex = 0; myIndex < number; myIndex++)
	{
		if(arr[pos] == arr[myIndex])
		{
			count++;
		}
	}
	
	if(count == 0)
	{
		printf("Array does not have this elements.");
	}
	else
	{
		for (myIndex = pos; myIndex < number - 1; myIndex++)
		{
			arr[myIndex] = arr[myIndex + 1];
		}
		
		printf("\nNew array we get is:\n");
		for (myIndex = 0; myIndex < number - 1; myIndex++)
		{
			printf("%d ", arr[myIndex]);
		}
	}
	printf("\n");
}

void printIncreasing()
{
	uint32_t j;
	uint32_t temp;
	uint32_t indexMin;
	for (myIndex = 0; myIndex < number - 1; myIndex++)
	{
		indexMin = myIndex;
		for (j = myIndex + 1; j < number; j++)
		{
			if (arr[indexMin] > arr[j])
			{
				indexMin = j;
			}
		}
		
		if (myIndex != indexMin)
		{
			temp = arr[myIndex];
			arr[myIndex] = arr[indexMin];
			arr[indexMin] = temp;
		}
	}
	
	printf("\nArray after sorter ascending: \n");
	for (myIndex = 0; myIndex < number; myIndex++)
	{
		printf("%d ", arr[myIndex]);
	}
	printf("\n");
}

void printDecreasing()
{
	uint32_t j;
	uint32_t temp;
	uint32_t indexMin;
	for (myIndex = 0; myIndex < number - 1; myIndex++)
	{
		indexMin = myIndex;
		for (j = myIndex + 1; j < number; j++)
		{
			if (arr[indexMin] < arr[j])
			{
				indexMin = j;
			}
		}
		
		if (myIndex != indexMin)
		{
			temp = arr[myIndex];
			arr[myIndex] = arr[indexMin];
			arr[indexMin] = temp;
		}
	}
	printf("\nArray after sorter ascending: \n");
	for (myIndex = 0; myIndex < number; myIndex++)
	{
		printf("%d ", arr[myIndex]);
	}
	printf("\n");
}

void find()
{
	uint32_t count = 0;
	printf("\nEnter the value you want to find: ");
	scanf("%d", &value);
	for (myIndex = 0; myIndex < number; myIndex++)
	{
		if (arr[myIndex] == value)
		{
			pos = myIndex;
			count++;
		}
	}
	
	if(count != 0)
	{
		printf("The position of value is: %d", pos);
	}
	else
	{
		printf("Array does not have you value.");
	}
	printf("\n");
}

void printMax()
{
	uint32_t max = arr[0];
	for (myIndex = 0; myIndex < number; myIndex++)
	{
		if (arr[myIndex] >= max)
		{
			max = arr[myIndex];
		}
	}

	printf("Max in array is: %d", max);
	printf("\n");
}

void printMin()
{
	uint32_t min = arr[0];
	for (myIndex = 0; myIndex < number; myIndex++)
	{
		if (arr[myIndex] <= min)
		{
			min = arr[myIndex];
		}
	}

	printf("Min in array is: %d", min);
	printf("\n");
}

void Program()
{
	uint8_t choose;
	uint8_t select;
	do
	{
		choose = Menu();
		fflush(stdin);
		switch (choose)
		{
			case 'c':
				clear();
				printf("\nData was cleared!!!\n");
				
				printf("\nDo you want to enter new array?");
				printf("\nEnter '1' if you want to enter.");
				printf("\nEnter '2' to exit.");
				printf("\nPlease enter you selection: ");
				scanf(" %c", &select);
				fflush(stdin);
				if (select == '1')
				{
					enter();
				}
			break;

			case 'p':
				print();
			break;

			case 'i':
				add();
			break;

			case 'd':
				erease();
			break;

			case 's':
				printIncreasing();
			break;

			case 'x':
				printDecreasing();
			break;

			case 't':
				find();
			break;

			case 'a':
				printMax();
			break;

			case 'w':
				printMin();
			break;

			case 'e':
			break;

			default:
				printf("Please enter your choose: ");
			break;
		}
	} while (choose != 'e');
}
/*******************************************************************************
 * End of file
 ******************************************************************************/

