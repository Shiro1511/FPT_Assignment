#ifndef _FUNCTION_H_
#define _FUNCTION_H_
/*******************************************************************************
 * Variables
 ******************************************************************************/
uint32_t arr[100] = {0}, myIndex, number, pos, value;
 /*******************************************************************************
 * API
 ******************************************************************************/
 
 /**
 * @brief           Print the selection list to the screen
 *                  for the user to choose
 * @param[in]       choose: the selection of user
 * @param[out]      None
 * @param[inout]    None
 * @returns         choose: the character user entered
 */
uint8_t Menu();

/**
 * @brief           Let the user enter the number elements of array
 *                  and enter elements  of array
 * @param[in]       number: the number elements of array
 *                  arr: array of data
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void enter();

 /**
 * @brief           Clear all data of the old array
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void clear();

/**
 * @brief           Add the value user enter to the position in array
 *                  and print array to the screen
 * @param[in]       value: the value of element
 *                  pos: the position in array
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void add();

/**
 * @brief           Delete the value user enter to the position in array
 *                  and print array to the screen
 * @param[in]       pos: the position in array
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void erease();

/**
 * @brief           Print the array sorted in ascending order to the screen
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void printIncreasing();

/**
 * @brief           Print the array sorted in descending order to the screen
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void printDecreasing();

/**
 * @brief           Print the position of the value user enterd
 *                  after had been found in array
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void find();

/**
 * @brief           Print to the screen the biggest number
 * @param[in]       value: the value user enterd to find in array
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void printMax();

/**
 * @brief           Print to the screen the smallest number
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void printMin();

/**
 * @brief           Contain Menu() for user choose the selection
 * @param[in]       choose: the character user enter to choose
 *                  select: the character user enter to choose
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void Program();

/**
 * @brief           Print array to the screen
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void print();

/**
 * @brief           To check array is empty or not
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         count: == 0 or not? == 0 -> array is empty
 */
uint32_t checkEmpty(uint32_t arr[]);

#endif /* _FUNCTION_H_ */
/*******************************************************************************
 * End of file
 ******************************************************************************/

