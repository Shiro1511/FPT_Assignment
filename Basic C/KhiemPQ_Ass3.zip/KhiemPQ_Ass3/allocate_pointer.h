#ifndef _ALLOCATE_POINTER_
#define _ALLOCATE_POINTER_

/**
 * @brief           allocate memory 10 bytes for 1 pointer
 *
 * @param[in]       pointer outPtr
 * @param[out]      None
 * @param[inout]    None
 * @returns         true if allocate memory successfully, false if allocate memory unsuccessfully
 */
bool allocate10Bytes(uint8_t *outPtr);

#endif /* _ALLOCATE_POINTER_ */
/*******************************************************************************
 * End of file
 ******************************************************************************/
