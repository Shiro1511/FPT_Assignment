/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdio.h>
#include <stdint.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define REG_BIT_SET32_MASK 0x00000001U
/**
* @brief 32 bits bits setting macro.
* Set bit in n, use operator '|'. When we want bit at n = 1, (address) OR with Mask shift left n
*/
#if !defined(REG_BIT_SET32)
  #define REG_BIT_SET32(address, n)      ((*(volatile uint32_t*)(address))|= (REG_BIT_SET32_MASK << (n)))
#endif

/**
* @brief 32 bits bits setting macro.
* Set bit in n, use operator '|'. When we want bit at n = 1, (address) AND with Mask shift left n
*/
#if !defined(REG_BIT_CLEAR32)
  #define REG_BIT_CLEAR32(address, n)    ((*(volatile uint32_t*)(address))&= ~(REG_BIT_SET32_MASK << (n)))
#endif

/**
* Convert big endian - little endian with 32 bit. Use (address) shift left 24
*                                                   OR (address)) & 0x0000FF00) <<  8) |\
            										OR	(((address) & 0x00FF0000) >>  8) |\
            										OR	(((address) & 0xFF000000) >> 24))
*/
#define SWAP_BYTE32(address)        (((((uint32_t) (address)) & 0x000000FF) << 24) |\
            						((((uint32_t) (address)) & 0x0000FF00) <<  8) |\
            						((((uint32_t) (address)) & 0x00FF0000) >>  8) |\
            						((((uint32_t) (address)) & 0xFF000000) >> 24))

/**
* Convert big endian - little endian with 32 bit. Use (((address & 0x00FF) << 8) |
            										((address & 0xFF00) >> 8))
*/
#define SWAP_BYTE16(address)        (((((uint16_t) (address)) & 0x00FF) << 8) |\
            						((((uint16_t) (address)) & 0xFF00) >> 8))
/*******************************************************************************
 * Main
 ******************************************************************************/
uint32_t main()
{
  uint32_t address = 0x98765432;
  uint16_t address1 = 0xFF;
  printf("Address: %x", &address);
  printf("\nREG_BIT_SET32: %x", REG_BIT_SET32(&address,6));
  printf("\nREG_BIT_CLEAR32: %x", REG_BIT_CLEAR32(&address,6));
  printf("\nSWAP_BYTE32: %x", SWAP_BYTE32(address));
  printf("\nSWAP_BYTE16: %x", SWAP_BYTE16(address1));
  return 0;
}
/*******************************************************************************
 * End of file
 ******************************************************************************/
