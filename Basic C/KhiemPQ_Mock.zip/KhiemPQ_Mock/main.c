/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "srec.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define FILE_IN_NAME  "Srec1.txt"   /* file using read */
#define FILE_OUT_NAME "Output.txt"  /* file using write */
/*******************************************************************************
 * Codes
 ******************************************************************************/
uint32_t main()
{
    FILE *openFile = NULL;
    FILE *printFile = NULL;
    int8_t srec[MAXLENGTH + 1];
    int8_t cur[MAXLENGTH + 1];
    int8_t line[MAXLENGTH + 1];
    SRecordErrors checkS = SRECORD_OK;
    SRecordErrors checkHexa = SRECORD_OK;
    SRecordErrors checkByteCount = SRECORD_OK;
    SRecordErrors checkSum = SRECORD_OK;
    SRecordErrors checklineCount = SRECORD_OK;
    SRecordErrors checkTerminate = SRECORD_OK;
    uint32_t index = 0;
    uint32_t k;
    uint32_t indexWrite = 0;
    uint32_t countline_Data = 0;
    uint32_t lineS[10] = {0,0,0,0,0,0,0,0,0,0};
    
    printFile = fopen(FILE_OUT_NAME, "w");
    if(printFile == NULL)
    {
        printf("Error! File cannot be written.\n");
    }
    
    openFile = fopen(FILE_IN_NAME, "r");
    if(openFile == NULL)
    {
        printf("Error! File cannot be opened.\n");
    }
    else
    {
        printf("Line    |Address        Data\n");
        fputs("Line   |Address        Data\n", printFile);

        while(fgets(srec, MAXLENGTH, openFile))
        {
            index++;
            checkS = check_S(srec[0]);
            checkHexa = check_Hexa(srec);
            checkByteCount = check_ByteCount(srec);
            checkSum = check_checkSum(srec);

            if(index == 1)
            {
                strcpy(line, srec);
            }

            if(Check_Data(srec) == true)
            {
                countline_Data++;
            }

            counttypeline(srec,&lineS[0]);
            checklineCount = check_lineCount(cur, countline_Data);
            if(printFile != NULL)
            {
               writeFile(srec, printFile, &indexWrite);
            }
            if(checkS == SRECORD_ERROR_S)
            {
                fputs("\tERROR 'S'", printFile);
                printf("   ERROR 'S'");
            }
            if(checkHexa == SRECORD_ERROR_HEXA)
            {
                fputs("\tERROR HEXA", printFile);
                printf("   ERROR HEXA");
            }
            if(checkByteCount == SRECORD_ERROR_BYTECOUNT)
            {
                fputs("\tERROR BYTE COUNT", printFile);
                printf("   ERROR BYTE COUNT");
            }
            else
            {
                if(checkSum == SRECORD_ERROR_CHECKSUM)
                {
                    fputs("\tERROR CHECK SUM", printFile);
                    printf("   ERROR CHECK SUM");
                }
                if((srec[1] == '5') || (srec[1] == '6'))
                {
                    strcpy(cur,srec);

                }
            }
            display(srec, &indexWrite);
        }
        checklineCount = check_lineCount(cur, countline_Data);
        if((checklineCount == SRECORD_ERROR_LINECOUNT) || (lineS[5] > 1) || (lineS[6] > 1))
        {
            fputs("\tERROR LINE COUNT", printFile);
            printf("   ERROR LINE COUNT");
        }
        checkTerminate = check_Terminate(srec, srec[1]);
        if(checkTerminate == SRECORD_ERROR_TERMINATE)
        {
            fputs("\tERROR TERMINATE", printFile);
            printf("   ERROR TERMINATE");
        }

        fclose(openFile);
    }
     if(printFile != NULL)
    {
        fclose(printFile);
    }

    return 0;
}
/*******************************************************************************
 * End of file
 ******************************************************************************/
