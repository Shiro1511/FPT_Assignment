/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "srec.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define H1(x) (x-('0'))
#define H2(x) (x-('A')+10)
/* convert 2 chr hexa to decimal */
#define CONVERT(Arr) \
    ((((Arr[0]) >= '0') & ((Arr[0]) <= '9') ? H1(Arr[0]) : H2(Arr[0]))<<4)| \
    (((Arr[1]) >= 'A') & ((Arr[1]) <= 'F') ? H2(Arr[1]) : H1(Arr[1]))
    /* convert 2 number to 1 number */
#define CONVERT2(A, B)   (A<<4) | B
/* convert 4 number to 1 number */
#define CONVERT4(A, B, C, D)   (A<<12) | (B<<8) | (C<<4) | D
/*******************************************************************************
 * Functions
 ******************************************************************************/
static int8_t CONVERTDEC(int8_t value)
{
    if((value >= '0') && (value <= '9'))
    {
        value = value - '0';
    }
    else
    {
        value = value - 'A' + 10;
    }
    
    return value;
}


bool Check_Data(int8_t srec[])
{
    int8_t temp = 0;
    bool result = false;

    temp = srec[1];
    if((temp == '1') || (temp == '2') || (temp == '3'))
    {
        result = true;
    }

    return result;
}

SRecordErrors check_S(int8_t value)
{
    SRecordErrors check = SRECORD_OK;
    
    if(value != 'S')
    {
        check = SRECORD_ERROR_S;
    }
    
    return check;
}

SRecordErrors check_Hexa(int8_t srec[])
{
    uint8_t index = 1;
    SRecordErrors check = SRECORD_OK;
    
    while((srec[index] != '\n') && (check != SRECORD_ERROR_HEXA))
    {
        if(((srec[index] < '0') || (srec[index] > '9')) &&
        (srec[index] < 'A') || (srec[index] > 'F'))
        {
            check = SRECORD_ERROR_HEXA;
        }
        index++;
    }
    
    return check;
}

SRecordErrors check_ByteCount(int8_t srec[])
{
    uint8_t index = 4;
    SRecordErrors check = SRECORD_OK;
    uint16_t byteCount = 0;
    int8_t add_byteCount[2] = {'0','0'};
    
    add_byteCount[0] = srec[2];
    add_byteCount[1] = srec[3];
    byteCount = CONVERT(add_byteCount);
    byteCount = byteCount << 1;
    while(srec[index] != '\n')
    {
        index++;
    }
    
    index = (index - 4);
    if(index != byteCount)
    {
        check = SRECORD_ERROR_BYTECOUNT;
    }
    
    return check;
}

SRecordErrors check_checkSum(int8_t srec[])
{
    SRecordErrors check = SRECORD_OK;
    uint8_t length;
    uint8_t size = 0;
    uint8_t index = 0;
    uint8_t sum = 0;
    uint8_t srecSum[2];
    
    length = strlen(srec);
    for (index = 2; index < length - 2; index = index + 2)
    {
        srecSum[0] = srec[index];
        srecSum[1] = srec[index+1];
        
        size = CONVERT2(CONVERTDEC(srecSum[0]), CONVERTDEC(srecSum[1]));
        sum = sum + size;
    }
    
    srecSum[0] = srec[length - 2];
    srecSum[1] = srec[length - 1];
    size = CONVERT2(CONVERTDEC(srecSum[0]), CONVERTDEC(srecSum[1]));
    if ((size + sum) == 255)
    {

        check = SRECORD_ERROR_CHECKSUM;
    }
    else
    {
        check = SRECORD_OK;
    }

    return check;
}

SRecordErrors check_lineCount(int8_t cur[], uint32_t countLine)
{
    SRecordErrors check = SRECORD_OK;
    uint32_t checkLine = 0;
    uint8_t length;

    checkLine = CONVERT4(CONVERTDEC(cur[4]), CONVERTDEC(cur[5]), CONVERTDEC(cur[6]), CONVERTDEC(cur[7]));
    if(checkLine != countLine)
    {
        check = SRECORD_ERROR_LINECOUNT;
    }
    else
    {
        check = SRECORD_OK;
    }
   
    return check;
}

SRecordErrors check_Terminate(int8_t srec[], int8_t value)
{
    SRecordErrors check = SRECORD_OK;
    uint8_t index;
    int8_t type;
    if(srec[1] == '1')     /* address start at Index = 4 end at Index = 7 */
    {
        type = '9';
    }
    else if(srec[1] == '2')/* address start at Index = 4 end at Index = 9 */
    {
        type = '8';
    }
    else if(srec[1] == '3')/* address start at Index = 4 end at Index = 12 */
    {
        type = '7';
    }

    if (value == type)
    {
        check = SRECORD_OK;
    }
    else
    {
        check = SRECORD_ERROR_TERMINATE;
    }
    
    return check;
}

void display(int8_t srec[], int32_t *indexWrite)
{
    uint8_t length = 0;
    uint8_t index = 0;
    uint8_t type = 0;        /* Record purpose data type */

    length = strlen(srec);
    if(srec[1] == '1')     /* address start at Index = 4 end at Index = 7 */
    {
        type = 0;
    }
    else if(srec[1] == '2')/* address start at Index = 4 end at Index = 9 */
    {
        type = 2;
    }
    else if(srec[1] == '3')/* address start at Index = 4 end at Index = 12 */
    {
        type = 4;
    }
    if((srec[1] == '1') || (srec[1] == '2') || (srec[1] == '3'))
    {
        printf("%-6u ",(*indexWrite));
        for(index = 4; index < 8 + type; index++)
        {
            printf("%c",srec[index]);
        }
        printf(" ");
        for(index = 8 + type; index < length - 3; index++)
        {
            printf("%c",srec[index]);
        }
        printf("\n");
    }
}

void writeFile(int8_t srec[], FILE* printFile, uint32_t *indexWrite)
{
    uint8_t length = 0;
    uint8_t index = 0;
    uint8_t type = 0;        /* Record purpose data type */

    length = strlen(srec);
    if(srec[1] == '1')     /* address start at index = 4 end at index = 7 */
    {
        type = 0;
    }
    else if(srec[1] == '2')/* address start at index = 4 end at index = 9 */
    {
        type = 2;
    }
    else if(srec[1] == '3')/* address start at index = 4 end at index = 12 */
    {
        type = 4;
    }
    if((srec[1] == '1') || (srec[1] == '2') || (srec[1] == '3'))
    {
        fprintf(printFile,"%-6u ",(*indexWrite)++);
        for(index = 4; index < 8 + type; index++)
        {
            fprintf(printFile,"%c",srec[index]);
        }
        fprintf(printFile," ");
        for(index = 8 + type; index < length - 3; index++)
        {
            fprintf(printFile,"%c",srec[index]);
        }
        fprintf(printFile,"\n");
    }
}

void counttypeline(int8_t srec[], uint32_t *ptrlineS)
{
    if(srec[1] == '0')
    {
        (*(ptrlineS+0))++;    /* number of line S0 increase */
    }
    else if(srec[1] == '1')
    {
        (*(ptrlineS+1))++;    /* number of line S1 increase */
    }
    else if(srec[1] == '2')
    {
        (*(ptrlineS+2))++;    /* number of line S2 increase */
    }
    else if(srec[1] == '3')
    {
        (*(ptrlineS+3))++;    /* number of line S3 increase */
    }
    else if(srec[1] == '4')
    {
        (*(ptrlineS+4))++;    /* number of line S4 increase */
    }
    else if(srec[1] == '5')
    {
        (*(ptrlineS+5))++;    /* number of line S5 increase */
    }
    else if(srec[1] == '6')
    {
        (*(ptrlineS+6))++;    /* number of line S6 increase */
    }
    else if(srec[1] == '7')
    {
        (*(ptrlineS+7))++;    /* number of line S7 increase */
    }
    else if(srec[1] == '8')
    {
        (*(ptrlineS+8))++;    /* number of line S8 increase */
    }
    else if(srec[1] == '9')
    {
        (*(ptrlineS+9))++;    /* number of line S9 increase */
    }
}
/*******************************************************************************
 * End of file
 ******************************************************************************/
