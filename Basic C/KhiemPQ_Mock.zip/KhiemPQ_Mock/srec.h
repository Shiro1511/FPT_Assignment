#ifndef _SREC_H_
#define _SREC_H_
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MAXLENGTH 80U
/*******************************************************************************
 * Type defination
 ******************************************************************************/
typedef enum SRecordErrors{
        SRECORD_OK,
        SRECORD_ERROR_S,
        SRECORD_ERROR_HEXA,
        SRECORD_ERROR_BYTECOUNT,
        SRECORD_ERROR_LINECOUNT,
        SRECORD_ERROR_TERMINATE,
        SRECORD_ERROR_CHECKSUM

}SRecordErrors;
/*******************************************************************************
 * API
 ******************************************************************************/

 /**
 * @brief           srec[1] exists Record field data or not
 *
 * @param[in]       srec: array of data
 * @param[out]      None
 * @param[inout]    None
 * @returns         true if exist, false if not
 */
extern bool Check_Data(int8_t srec[]);

 /**
 * @brief           Is the character 'S' or not
 *
 * @param[in]       value: character using check
 * @param[out]      None
 * @param[inout]    None
 * @returns         SRECORD_OK if right, SRECORD_ERROR_S if not
 */
extern SRecordErrors check_S(int8_t value);

 /**
 * @brief           Is there a non-hexa character
 *                  starting from srec[1] in the data.
 * @param[in]       srec: array of data
 * @param[out]      None
 * @param[inout]    None
 * @returns         SRECORD_OK if right, SRECORD_ERROR_HEXA if not
 */
extern SRecordErrors check_Hexa(int8_t srec[]);

 /**
 * @brief           Is the number of characters added or lost.
 *
 * @param[in]       srec: array of data
 * @param[out]      None
 * @param[inout]    None
 * @returns         SRECORD_OK if no change, SRECORD_ERROR_BYTECOUNT if change
 */
extern SRecordErrors check_ByteCount(int8_t srec[]);

 /**
 * @brief           Data has failed hay do not.
 *
 * @param[in]       srec: array of data
 * @param[out]      None
 * @param[inout]    None
 * @returns         SRECORD_OK if no change, SRECORD_ERROR_CHECKSUM if change
 */
extern SRecordErrors check_checkSum(int8_t srec[]);

 /**
 * @brief           Is the number of lines containing the data
 *                  of the record file enough.
 * @param[in]       cur: data of Record field S5 or S6
 * @param[out]      None
 * @param[inout]    None
 * @returns         SRECORD_OK if no change, SRECORD_ERROR_LINECOUNT if change
 */
extern SRecordErrors check_lineCount(int8_t cur[], uint32_t countLine);

 /**
 * @brief           Record purpose Termination matches
 *                  data Record purpose or not.
 * @param[in]       srec: data of Record field S7 or S8 or S9
 * @param[in]       value : character using check
 * @param[out]      None
 * @param[inout]    None
 * @returns         SRECORD_OK if match, SRECORD_ERROR_TERMINATE if no match
 */
extern SRecordErrors check_Terminate(int8_t srec[], int8_t value);

 /**
 * @brief           Print out the screen number of lines
 *                  of record fields S1, S2, S3 , S4 with error.
 * @param[in]       srec : array of data
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
extern void display(int8_t srec[], int32_t *indexWrite);

 /**
 * @brief           Print the lines containing the Record field to the file
 *
 * @param[in]       srec: array of data
 * @param[out]      None
 * @param[inout]    Indexwrite: poiter of numline printed
 * @param[inout]    writefilePtr: poiter of file write
 * @returns         None
 */
void writeFile(int8_t srec[], FILE* printFile, uint32_t *indexWrite);

 /**
 * @brief           count the number of occurrence of record fields
 *
 * @param[in]       string: array of data
 * @param[out]      None
 * @param[inout]    ptrlineS: poiter of array contains of occur of record fields
 * @returns         None
 */
extern void counttypeline(int8_t srec[], uint32_t *ptrlineS);
#endif /* _SREC_H_ */
/*******************************************************************************
 * End of file
 ******************************************************************************/
