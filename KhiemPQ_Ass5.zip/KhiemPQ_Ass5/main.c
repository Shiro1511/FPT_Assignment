/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "student.h"
/*******************************************************************************
 * Codes
 ******************************************************************************/
uint32_t main()
{
	uint8_t choose;
	studentList *list = NULL;
	
	/* Interactive interface */
	printf("		**********Student achievement management system**********\n");
	printf("		*  1.Enter new student grades                          *\n");
	printf("		*  2.Modify student grades by ID                       *\n");
	printf("		*  3.Remove student grades by ID                       *\n");
	printf("		*  4.Query student scores by ID                        *\n");
	printf("		*  5.Output the results of all students                *\n");
	printf("		*  6.Output student scores by average                  *\n");
	printf("		*  7.Exit student achievement management system        *\n");
	printf("		********************************************************\n");
	printf("  	                                                			\n");
	/* Create student linked list */
	list = (studentList *)malloc(sizeof(studentList));
	/* Initialize student linked list */
	initialize(list);
	/* Read data from file to linked list */
	read(list);
	/* The interactive interface is written with an infinite loop and a switch */
	do
	{
		printf("Please enter the number corresponding to the operation you want to perform: ");
		scanf(" %c", &choose);
		switch (choose)
		{
			case '1':
				enter(list);
				break;
			case '2':
				modify(list);
				break;
			case '3':
				del(list);
			    break;
			case '4':
				find(list);
				break;
			case '5':
				display(list);
				break;
			case '6':
				sort(list);
				break;
			case '7':
				write(list);
				free(list->head);	/* The header node is destroyed */
				free(list);		/* The linked list was destroyed */
				break;
			default:
				printf("%c Is an invalid number, please re-enter!\n\n", choose);
				break;
		}
	} while(choose != '7');
	return 0;
}
/*******************************************************************************
 * End of file
 ******************************************************************************/
