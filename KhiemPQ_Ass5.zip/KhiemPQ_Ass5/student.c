/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "student.h"
/*******************************************************************************
 * Functions
 ******************************************************************************/
void initialize(studentList *list)/* Initialize the list, create the header node */
{
    studentNode *student = NULL;

	student =  (studentNode *)malloc(sizeof(studentNode));
	student -> next = NULL;
	list -> head = student;
	list -> tail = student;
	list -> count = 0;
}

void enter(studentList *list)/* Enter linked list */
{
	studentNode *student = NULL;

	student = (studentNode *)malloc(sizeof(studentNode));
	printf("Please enter student ID: ");
	scanf("%d", &student -> student.ID);
	printf("Please enter student name: ");
	scanf(" %s", student -> student.name);
	fflush(stdin);
	printf("Please enter student Math score: ");
	scanf("%f", &student -> student.score);
	if (list -> head == list -> tail)
	{
        list -> tail = student;
	}
	/* Insert the new node into the head of the linked list (head insertion method) */
	student -> next = list -> head -> next;
	list -> head -> next = student;
	list -> count++;
	/* Output interactive information */
	printf("Information entered successfully!\n\n");

}

void display(studentList *list)/* Output linked list */
{
	studentNode *ptr = NULL;
	
	printf("Student ID\t\t Full Name\t\t Math Score\t\t\n");
	/* Create a node pointer to the head node */
	ptr = list -> head;
	/* Traversal list output */
	while (ptr -> next) {
		ptr = ptr -> next;
		printf("%d", ptr -> student.ID);
		printf("\t\t%s", ptr -> student.name);
		printf("\t\t\t\t%.2f", ptr -> student.score);
		printf("\n");
	}
	printf("\n");
	
}

void find(studentList *list)/* Find a node */
{
	uint32_t ID;
	studentNode *ptr = NULL;
	
	printf("Please enter student ID: ");
	scanf("%d", &ID);
	/* Traverse the linked list and compare ID */
	ptr = list -> head -> next;
	while (ptr)
	{
		/* If it matches, output and end the function */
		if (ptr -> student.ID == ID)
		{
			printf("Student ID\t\t Full Name\t\t Math Score\n");
			printf("%d", ptr -> student.ID);
			printf("\t\t%s", ptr -> student.name);
			printf("\t\t\t\t%.2f", ptr -> student.score);
			printf("\n\n");
			return;
		}
		/* If the ID doesn't match, it's next */
		ptr = ptr -> next;
	}
	/* I didn't find the name in the traversal */
	printf("I didn't find this ID: %d Information!\n\n", ID);

}

void modify(studentList *list)/* Modify a node */
{
	/* Let the user enter the student to modify */
	uint32_t ID;
	studentNode *ptr = NULL;
	
	printf("Please enter student ID: ");
	scanf("%d", &ID);
	//Traverse the linked list and compare ID
	ptr = list -> head -> next;
	while (ptr)
	{
		/* If yes, let the user retype and end the function */
		if (ptr -> student.ID == ID)
		{
			printf("Please re-enter the information:\n");
			printf("Please enter student ID: ");
			scanf("%d", &ptr->student.ID);
			printf("Please enter your name: ");
			scanf(" %s", &ptr->student.name);
			fflush(stdin);
			printf("Please enter your Math score: ");
			scanf("%f", &ptr -> student.score);
			printf("Information modified successfully!\n\n");
			return;
		}
		/* If the ID doesn't match, it's next */
		ptr = ptr -> next;
	}
	/* I didn't find the name in the traversal */
	printf("I didn't find this ID: %d Information!\n\n", ID);

}

void del(studentList *list)/* Remove a node */
{
	uint32_t ID;
	studentNode *ptr1 = NULL;
	studentNode *ptr2 = NULL;
	
	ptr1 = list -> head;
	ptr2 = list -> head;
	/* Let the user enter the student to remove */
	printf("Please enter student ID: ");
	scanf("%d", &ID);
	/* Traverse the linked list and compare ID */
	while (ptr1 != NULL)
	{
		if (ptr1 -> student.ID == ID)
		{
			if(ptr1 == ptr2)
			{
				list -> head = list -> head -> next;
				free(ptr1);
			}
	        else
	        {
	        	ptr2->next =ptr1->next;
	        	free(ptr1);
			}
	        /* Output interactive information */
            printf("Information removed successfully!\n\n");
            list -> count--;
			return;
		}
		/* If the ID doesn't match, it's next */
		ptr2 = ptr1;
		ptr1 = ptr1->next;
	}
	/* I didn't find the name in the traversal */
	printf("I didn't find this ID: %d Information!\n\n", ID);
}

void sort(studentList *list)/* Rebuild the table in descending order and output */
{
	/* Insert sort */
	studentNode *ptr = NULL;
	studentNode *prev = NULL;
	studentNode *temp = NULL;
	
	/* Neither node is in fast order */
	if (list -> count < 2)
	{
		printf("List sorting completed!\n");
		display(list);
		return;
	}
	
	/* ptr points to the second student node */
	ptr = list -> head -> next;
	/* The linked list is disconnected from the head node and the first student node */
	list -> head -> next = NULL;
	/* Cycle back from the first student node */
	while (ptr)
	{
		/* Save the pointer of the next node */
		temp = ptr -> next;
		/* Find insertion location */
		prev = list -> head;
		while (prev -> next != NULL && prev -> next -> student.score > ptr -> student.score)
		{
			prev = prev -> next;
		}
			
		/* Update tail pointer */
		if (prev -> next == NULL)
		{
			list -> tail = ptr;
		}
		/* Insert */
		ptr -> next = prev -> next;
		prev -> next = ptr;
		/* Skip to next */
		ptr = temp;
	}
	printf("List sorting completed!\n");
	display(list);
}

void write(studentList *list)/* Write files to free up space while writing */
{
	studentNode *ptr = NULL;
	studentNode *next;
	/* Open file flow */
	FILE *fpt = fopen(FILE_NAME, "w");
	
	if (fpt == NULL) {
		printf("file%s Open failed\n", FILE_NAME);
		exit(EXIT_FAILURE);
	}
	/* Output the total number of student nodes on the first line */
	fprintf(fpt, "%d\n", list -> count);
	/* Create a node pointer to the head node */
	ptr = list -> head -> next;
	/* Traverse the linked list and output a set of data as a row */
	while (ptr) {
		fprintf(fpt, "%d ", ptr->student.ID);
		fprintf(fpt, "%s ", ptr->student.name);
		fprintf(fpt, "\t\t\t%.2f ", ptr->student.score);;
		fprintf(fpt, "\n");
		/* Free node space after output */
		next = ptr -> next;
		free(ptr);
		ptr = next;
	}
	/* Close file stream */
	fclose(fpt);
	/* Interactive information */
	printf("Data saved! Thanks for using. Bye!\n");
}

void read(studentList *list)
{
	studentNode *student = NULL;
	uint32_t myIndex;
	/* Open file stream */
	FILE *fpt = fopen(FILE_NAME, "r");
	
	if (fpt == NULL) {
		printf("file%s Open failed\n", FILE_NAME);
		exit(EXIT_FAILURE);
	}
	/* Read the total number of student nodes in the first row */
	fscanf(fpt, "%d", &list -> count);
	/* The data is read circularly, and the number of cycles is count */
	for (myIndex = 1; myIndex <= list -> count; myIndex++)
	{
		/* Create a new node */
		student = (studentNode *)malloc(sizeof(studentNode));
		/* Read data */
 		fscanf(fpt, "%d ", &student->student.ID);
		fscanf(fpt, "%s ", student->student.name);
		fscanf(fpt, "%f ", &student->student.score);
		//Insert the new node into the tail of the linked list (tail insertion method)
		student -> next = NULL;
		list -> tail -> next = student;
		list -> tail = student;
	}
	/* Close file stream */
	fclose(fpt);
}
/*******************************************************************************
 * End of file
 ******************************************************************************/
