#ifndef _STUDENT_H_
#define _STUDENT_H_
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define NAME_LENGTH 15
#define FILE_NAME "student.txt"
/*******************************************************************************
 * Type defination
 ******************************************************************************/
typedef float float32_t;
 
typedef struct
{
	uint32_t ID;
	uint8_t name[NAME_LENGTH];
	float32_t score;
} student;

typedef struct node
{
	student student;
	struct node *next;
} studentNode;

typedef struct {
	studentNode *head;	/* Head pointer */
	studentNode *tail;	/* Tail pointer */
	uint32_t count;		/*Total number of student nodes */
} studentList;
/*******************************************************************************
 * API
 ******************************************************************************/

  /**
 * @brief           Initialize the list, create the header node
 *
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void initialize(studentList *list);

  /**
 * @brief           Enter linked list
 *
 * @param[in]       student ID, Name, Math score
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void enter(studentList *list);

  /**
 * @brief           Output linked list
 *
 * @param[in]       None
 * @param[out]      student ID, Name, Math score
 * @param[inout]    None
 * @returns         None
 */
void display(studentList *list);

  /**
 * @brief           Find a student by ID
 *
 * @param[in]       student ID
 * @param[out]      student ID, Name, Math score
 * @param[inout]    None
 * @returns         None
 */
void find(studentList *list);


  /**
 * @brief           Modify a student by ID
 *
 * @param[in]       student ID
 *                  student ID, Name, Math score
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void modify(studentList *list);

  /**
 * @brief           Delete a student by ID
 *
 * @param[in]       student ID
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void del(studentList *list);

  /**
 * @brief           Rebuild the table in descending order and output
 *
 * @param[in]       None
 * @param[out]      student ID, Name, Math score
 * @param[inout]    None
 * @returns         None
 */
void sort(studentList *list);

  /**
 * @brief           Write files to free up space while writing
 *
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void write(studentList *list);

  /**
 * @brief           Read files was saved
 *
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void read(studentList *list);

#endif /* _STUDENT_H_ */
/*******************************************************************************
 * End of file
 ******************************************************************************/
