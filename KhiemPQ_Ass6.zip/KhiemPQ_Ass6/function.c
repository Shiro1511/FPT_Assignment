/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "function.h"
/*******************************************************************************
 * Functions
 ******************************************************************************/
uint32_t checkExist(uint8_t array[], uint8_t value)
{
    uint8_t index;
    uint32_t suitable = 0;

    for(index = 0; index <= 19; index ++)
    {
        if(array[index] == value)
        {
            suitable = 1;
        }
    }

    return suitable;
}

uint8_t enter(uint8_t value)
{
    uint8_t select;
    uint8_t index;
    uint8_t exist;
    uint32_t suitable;
    
    suitable = checkExist(dataArray, value);

    if ((value >= 0) && (value <= 100))
    {
        if (suitable == 1)
        {
            exist = '0';
        }
        else
        {
            exist = '1';
            printf("\n		Add successfull!");
        }
    }
    else
    {
        printf("		%d is over scope!!! Please re-enter the other value!!", value);
        printf("\n		Add unsuccessful!!");
    }

    return exist;
}

void addValue()
{
    uint32_t position;
    uint32_t value;
    uint8_t select;
    uint8_t head_prev;
    uint8_t temp;
    uint8_t exist;
    uint8_t check = '0';

    printf("		Enter the position [0, 19]: ");
    scanf("%d", &position);

    if ((position >= 0) && (position <= 19))
    {
        if (dataArray[position] == 255)
        {
            select = '1';
        }
        else
        {
            select = '2';
            printf("		%d was added before!! Please re-enter the other position!!", position);
        }
    }
    else
    {
        select = '2';
        printf("		%d is over scope!!! Please re-enter the other the other position!!", position);
    }

    switch (select)
    {
        case '1':
            printf("		Enter the value [0, 100]: ");
            scanf("%d", &value);

            exist = enter(value);
            break;

        case '2':
            break;

        default:
            printf("Invalid!!!");
            break;
    }

    if (exist == '1')
    {
        head_prev = head;
        dataArray[position] = value;
        if (head == 255)
        {
            head = position;
        }
        else if (dataArray[head_prev] > value)
        {
            pNext[position] = head;
            head = position;
        }
        else
        {
            while ((pNext[head_prev] != 255) && (check == '0'))
            {
                temp = pNext[head_prev];
                if (dataArray[temp] > value)
                {
                    check = '1';
                    pNext[position] = pNext[head_prev];
                    pNext[head_prev] = position;
                }
                head_prev = pNext[head_prev];
            }

            if (check == '0')
            {
                pNext[head_prev] = position;
            }
        }
    }
    else if(exist == '0')
    {
        printf("\n		Unsucccessful!! Your value was added before!!");

    }
}

void printUnsorted()
{
    uint8_t index;

    printf("\t\tHead is : %d",head);
    printf("\n  Index\t");
    for (index = 0; index <= 19; index++)
    {
        printf("%5d", index);
    }

    printf("\n   data\t");
    for (index = 0; index <= 19; index++)
    {
        printf("%5d", dataArray[index]);
    }

    printf("\n  pNext\t");
    for (index = 0; index <= 19; index++)
    {
        printf("%5d", pNext[index]);
    }
}

void printSorted()
{
    uint8_t index = 0;
    uint8_t head_prev;

    head_prev = head;
    printf("\t\tHead is : %d",head);
    printf("\n     i\t");
    while (head_prev !=255)
    {
        printf("%5d",head_prev);
        head_prev = pNext[head_prev];
    }

    head_prev = head;
    printf("\n   data\t");
    while (head_prev != 255)
    {
        printf("%5d",dataArray[head_prev]);
        head_prev = pNext[head_prev];
    }

    head_prev = head;
    printf("\n  pNext\t");
    while (head_prev !=255)
    {
        printf("%5d",pNext[head_prev]);
        head_prev = pNext[head_prev];
    }
}

uint8_t checkValue(uint32_t value)
{
    uint8_t check;
    uint8_t index;

    if ((value >= 0) && (value <= 100))
    {
        for(index = 0; index <= 19; index++)
        {
            if(dataArray[index] == value)
            {
                check = '1';
                index = 20;
            }
            else
            {
                check = '2';
            }
        }

    }
    else
    {
        check = '0';
    }

    return check;
}

void delValue()
{
    uint8_t index;
    uint8_t head_prev;
    uint32_t position;
    uint32_t value;
    uint8_t check;

    printf("\t\t\tPlease enter value you want to delete [0, 100]: ");
    scanf("%d", &value);

    check = checkValue(value);

    switch(check)
    {

        case '1':
            head_prev = head;

            if(position == head)
            {
                dataArray[position] = 255;
                head = pNext[position];
                pNext[head_prev] = 255;
            }
            else
            {
                while((pNext[head_prev] != 255))
                {
                    index = pNext[head_prev];
                    if(dataArray[index] == value)
                    {
                        dataArray[index] = 255;
                        pNext[head_prev] = pNext[index];
                        pNext[index] = 255;
                    }
                    head_prev = pNext[head_prev];
                }
            }
            printf("\n		Your value was removed successfully!!");
            break;

        case '2':
            printf("\n		Your value is not in array!!");
            break;

        case '0':
            printf("\n		Your value is over scope!!");
            break;

        default:
            break;
    }
}
/*******************************************************************************
 * End of file
 ******************************************************************************/
