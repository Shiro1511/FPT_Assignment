#ifndef _FUNCTION_H_
#define _FUNCTION_H_
/*******************************************************************************
 * Variables
 ******************************************************************************/
extern uint8_t dataArray[20];
extern uint8_t pNext[20];
extern uint8_t head;
/*******************************************************************************
 * API
 ******************************************************************************/
 
  /**
 * @brief           check value belong array?
 *
 * @param[in]       array: array of dataArray
 *                  value: value user entered
 * @param[out]      None
 * @param[inout]    None
 * @returns         suitable: = 1 if belong to array and else = 0
 */
uint32_t checkExist(uint8_t array[], uint8_t value);

 /**
 * @brief           check value is suitable for condition and it belong array?
 *
 * @param[in]       value: value user entered
 * @param[out]      None
 * @param[inout]    None
 * @returns         exist: = 1 if suitable for condition and else = 0
 */
uint8_t enter(uint8_t value);

 /**
 * @brief           Add value to array with position and value were entered
 *                  by user
 * @param[in]       position: position user entered
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void addValue();

/**
 * @brief           Print index, dataArray and pNext to the screen
 *
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void printUnsorted();

/**
 * @brief           Sorter dataArray ascending
 *                  and print index, dataArray, pNext to the screen
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void printSorted();

 /**
 * @brief           check value is suitable for condition and it belong array to delete?
 *
 * @param[in]       value: value user entered
 * @param[out]      None
 * @param[inout]    None
 * @returns         check: = '1' if suitable for condition
 *                         = '2' if suitable for condition but not in array
 *                         = '0 if not suitable for condition
 */
uint8_t checkValue(uint32_t value);

/**
 * @brief           Delete dataArray from array
 *
 * @param[in]       value: value user entered
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void delValue();

#endif /* _FUNCTION_H_ */
/*******************************************************************************
 * End of file
 ******************************************************************************/

