/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "function.h"
/*******************************************************************************
 * Variables
 ******************************************************************************/
uint8_t dataArray[20] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
                         255, 255, 255, 255, 255, 255, 255, 255, 255, 255};

uint8_t pNext[20] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
                     255, 255, 255, 255, 255, 255, 255, 255, 255, 255};

uint8_t head = 255;
/*******************************************************************************
 * Codes
 ******************************************************************************/
uint32_t main()
{
    uint8_t choose;
    uint8_t option;

    printf("		*************Management Static Linked List*************\n");
    printf("		*  1.Enter                                            *\n");
    printf("		*  2.Remove                                           *\n");
    printf("		*  3.Print                                            *\n");
    printf("		*  4.Exit                                             *\n");
    printf("		*******************************************************\n");
    do
    {
        printf("\n		Please enter you choose: ");
        scanf(" %c", &choose);
        switch (choose)
        {
            case '1':
                addValue();
                break;

            case '2':
                printUnsorted();
                delValue();
                break;

            case '3':
                printf("		***************Print Static Linked List***************\n");
                printf("		*  1.Print without sorting                            *\n");
                printf("		*  2.Sorted and print                                 *\n");
                printf("		*  3.Exit                                             *\n");
                printf("		*******************************************************\n");
                do
                {
                    printf("\n		Please enter you selection: ");
                    scanf(" %c", &option);
                    switch(option)
                    {
                        case '1':
                            printUnsorted();
                            break;

                        case '2':
                            printSorted();
                            break;

                        case '3':
                            break;

                        default:
                            printf("		%c Is an invalid number, please re-enter!\n", option);
                            break;
                    }
                } while(option != '3');

                break;

            case '4':
                break;

            default:
                printf("		%c Is an invalid number, please re-enter!\n", choose);
                break;
        }
    } while (choose != '4');

    return 0;
}
/*******************************************************************************
 * End of file
 ******************************************************************************/

