/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "MKL46Z4.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define DELAY_CNT            (1000000)
#define RED_LED_ON           GPIOE->PCOR |= (1 << 29)
#define RED_LED_OFF          GPIOE->PSOR |= (1 << 29)
#define RED_LED_TOGGLE       GPIOE->PTOR |= (1 << 29)
/*******************************************************************************
 * API
 ******************************************************************************/

 /**
 * @brief           Inition LED RED
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void initLed();

 /**
 * @brief           Inition button Switch 1
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void initButton();

 /**
 * @brief           Delay of button
 * @param[in]       DELAY_CNT: time delay
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void delay();
/*******************************************************************************
 * Codes
 ******************************************************************************/
int main(void)
{
    initLed();
    initButton();
    while (1)
    {
        if((GPIOC->PDIR & 8U) == 0)
        {
            RED_LED_TOGGLE;
            delay();
        }
    }
}
/*******************************************************************************
 * Functions
 ******************************************************************************/
void initLed()
{
    /* Enable clock for PORTE */
    SIM->SCGC5 |= (1 << 13);    /* Set bit 13 */
    
    /* Configure multiplex of PTE29 as GPIO */
    PORTE->PCR[29] |= PORT_PCR_MUX(1);
    
    /* Configure PTE29 as output */
    GPIOE->PDDR |= (1 << 29);
}

void initButton()
{
    /* Enable clock for PORTC */
    SIM->SCGC5 |= ( 1 << 11 );
    
    /* Initialize the Switch 1 (PTC3) */
    PORTC->PCR[3] |= ( 1 << 8 );
    PORTC->PCR[3] &= ~( 1 << 9 );
    PORTC->PCR[3] &= ~( 1 << 10 );
    
    /* Config pin 3 as input pin */
    GPIOC->PDDR &= ~( 1 << 3 );
    
    /* Config pull up for pin 3 of PORTC */
    PORTC->PCR[3] |= ( 1 << 1 );
    PORTC->PCR[3] |= ( 1 << 0 ); 
}

void delay()
{
    uint32_t index;
    for (index = 0; index < DELAY_CNT; index++)
    {
        __asm("nop");
    }
}
/*******************************************************************************
 * End of file
 ******************************************************************************/
