/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "MKL46Z4.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define GREEN_LED_ON      GPIOD->PCOR |= (1 << 5)
#define GREEN_LED_OFF     GPIOD->PSOR |= (1 << 5)
#define RED_LED_ON        GPIOE->PCOR |= (1 << 29)
#define RED_LED_OFF       GPIOE->PSOR |= (1 << 29)
#define GREEN_LED_TOGGLE      GPIOD->PTOR |= (1 << 5)
#define RED_LED_TOGGLE        GPIOE->PTOR |= (1 << 29)
#define RELOAD_VALUE          0x51EBU
/*******************************************************************************
 * Variables
 ******************************************************************************/
uint32_t count = 0;
/*******************************************************************************
 * API
 ******************************************************************************/

 /**
 * @brief           Initialize LED RED and GREEN
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void initLed();

/**
 * @brief           Initialize button Switch 1
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void init_Button();

/**
 * @brief           Initialize systick timer
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void Init_SysTick();

/**
 * @brief           Count period and GREEN_LED toggle
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void SysTick_Handler(void);

/**
 * @brief           Press SW1 to control brightness of RED_LED
 * @param[in]       None
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void PORTC_PORTD_IRQHandler(void);
/*******************************************************************************
 * Codes
 ******************************************************************************/
void main()
{
    initLed();
    init_Button();
    Init_SysTick();
    NVIC_EnableIRQ(PORTC_PORTD_IRQn);
    while (1)
    {
        
    }
}
/*******************************************************************************
 * Functions
 ******************************************************************************/
void init_Button()
{
    /* Enable clock for PORTC */
    SIM->SCGC5 |= ( 1 << 11 );
    
    /* Initialize the Switch 1 (PTC3) */
    PORTC->PCR[3] |= ( 1 << 8 );
    PORTC->PCR[3] &= ~( 1 << 9 );
    PORTC->PCR[3] &= ~( 1 << 10 );
    
    /* Config pin 3 as input pin */
    GPIOC->PDDR &= ~( 1 << 3 );
    
    /* Config pull up for pin 3 of PORTC */
    PORTC->PCR[3] |= ( 1 << 1 );
    PORTC->PCR[3] |= ( 1 << 0 ); 
    
    /* Config interrupt with falling edge mode */
    PORTC->PCR[3] |= (1 << 19) | (1 << 17);
    PORTC->PCR[3] &= ~(1 << 18) & (~(1 << 16));   
}

void initLed()
{
    /* Enable clock for PORTD, PORTE */
    SIM->SCGC5 |= (1 << 12);    /* Set bit 12 */
    SIM->SCGC5 |= (1 << 13);    /* Set bit 13 */
    
    /* Configure multiplex of PTD5 and PTE29 as GPIO */
    PORTD->PCR[5] |= PORT_PCR_MUX(1);
    PORTE->PCR[29] |= PORT_PCR_MUX(1);
    
    /* Configure PTD5 and PTE29 as output */
    GPIOD->PDDR |= (1 << 5);
    GPIOE->PDDR |= (1 << 29);
    
    /* Clear PTD5 and PTE29 */
    RED_LED_ON;
    GREEN_LED_ON;
}

void Init_SysTick(){
    /* */
    SysTick->CTRL |= 0x0;
    /* */
    SysTick->CTRL |= ((1 << 2) | (1 << 1) | (1 << 0)) ;
    /* */
    SysTick->LOAD |= RELOAD_VALUE;
    /* */
    SysTick->VAL |= 0U;
    

}
void SysTick_Handler(void)
{
    if (count >= 1000)
    {
        count = 0;
    }
  
    if ((count == 500)|| (count == 0))
    {
        GREEN_LED_TOGGLE;
    }

    count++;
}

void PORTC_PORTD_IRQHandler(void)
{
    if (((PORTC->PCR[3] >> 24) & 0x01) == 1)
    {
        /* Clear flag */
        PORTC->PCR[3] |= (1 << 24);
        RED_LED_TOGGLE;
    }
}
/*******************************************************************************
 * End of file
 ******************************************************************************/
