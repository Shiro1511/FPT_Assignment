/*******************************************************************************
* Include
*******************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include "Queue_array.h"
/*******************************************************************************
* Function
*******************************************************************************/
uint8_t func_queue_empty(uint8_t queue_level)
{
    uint8_t check;

    if(queue_level == 0)
    {
        check = 0;
    }

    return check;
}

uint8_t func_queue_full(uint8_t queue_level)
{
    uint8_t check;

    if(queue_level == 4)
    {
        check = 1;
    }

    return check;
}

uint8_t *func_queue_pop(uint8_t (*queue_array) [80], uint8_t *queue_level,
                        uint8_t *queue_pop)
{
    uint8_t index;

    if(func_queue_empty(*queue_level) != 0)
    {
        (*queue_level)--;
        index = *queue_pop;
        (*queue_pop)++;
        if((*queue_pop) > 3)
        {
            *queue_pop = 0;
        }
    }

    return queue_array[index];
}

void func_queue_push(uint8_t (*queue_array) [80], uint8_t *queue_level,
                     uint8_t *queue_push, uint8_t temp, uint8_t *index)
{
    uint8_t *ptr = NULL;

    if((func_queue_full(*queue_level)) == 1)
    {
        
    }
    else
    {
        if((*queue_push) > 3)
        {
            *queue_push = 0;
        }
        ptr = &queue_array[*queue_push][*index];
        (*ptr) = temp;
        (*index)++;
        
        if((*ptr) == '\n')
        {
            (*queue_push)++;
            (*queue_level)++;
            (*index) = 0;
        }
    }
}
/*******************************************************************************
* End of file
*******************************************************************************/