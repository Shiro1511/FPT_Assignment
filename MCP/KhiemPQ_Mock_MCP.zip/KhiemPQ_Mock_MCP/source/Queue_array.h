#ifndef _QUEUE_ARRAY_H_
#define _QUEUE_ARRAY_H_
/*******************************************************************************
 * API
 ******************************************************************************/

/**
 * @brief           Check array is empty? 
 * @param[in]       queue_level: count lines
 * @param[out]      None
 * @param[inout]    None
 * @returns         check = 0 if array is empty 
 */
uint8_t func_queue_empty(uint8_t queue_level);

/**
 * @brief           Check array is full? 
 * @param[in]       queue_level: count lines
 * @param[out]      None
 * @param[inout]    None
 * @returns         check = 1 if array is full
 */
uint8_t func_queue_full(uint8_t queue_level);

/**
 * @brief           Pop queue_array 
 * @param[in]       queue_array, queue_level,
 *                  queue_pop
 * @param[out]      None
 * @param[inout]    None
 * @returns         queue_array 
 */
uint8_t *func_queue_pop(uint8_t (*queue_array) [80], uint8_t *queue_level,
                        uint8_t *queue_pop);

/**
 * @brief           Push queue_array 
 * @param[in]       queue_array, queue_level,
 *                  queue_push, temp, index
 * @param[out]      None
 * @param[inout]    None
 * @returns         None 
 */
void func_queue_push(uint8_t (*queue_array) [80], uint8_t *queue_level,
                     uint8_t *queue_push, uint8_t temp, uint8_t *index);

#endif /* _QUEUE_ARRAY_H_ */
/*******************************************************************************
* End of file
*******************************************************************************/