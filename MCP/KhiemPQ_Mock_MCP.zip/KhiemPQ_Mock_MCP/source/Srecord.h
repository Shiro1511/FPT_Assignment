#ifndef _SRECORD_H_
#define _SRECORD_H_
/*******************************************************************************
 * API
 ******************************************************************************/

/**
 * @brief           Convert 2 Hexa characters to decimal 
 * @param[in]       String
 * @param[out]      None
 * @param[inout]    None
 * @returns         Decimal of Hexa 
 */
uint8_t Convert_2_Hexa(uint8_t *str);

/**
 * @brief           Number of bits address for each S_type
 * @param[in]       S_type
 * @param[out]      Number of bits address for S_type
 * @param[inout]    None
 * @returns         Number of Address 
 */
uint8_t address_S(uint8_t S_type);

/**
 * @brief           Value power to base 16
 * @param[in]       Radix base
 * @param[out]      Value power of base 16
 * @param[inout]    None
 * @returns         Value total 
 */
uint32_t Pow16(uint8_t base);

/**
 * @brief           Convert Hexa to decimal (1-9) (A-F)
 * @param[in]       Char Hexa
 * @param[out]      Number after converted
 * @param[inout]    None
 * @returns         Decimal value of Hexa 
 */
uint8_t hexa_to_dec(uint8_t char_hexa );

/**
 * @brief           Convert Hexa to decimal value
 * @param[in]       String hexa
 * @param[out]      Value decimal of hexa
 * @param[inout]    None
 * @returns         Value decimal of hexa 
 */
uint32_t Convert_to_dec(uint8_t *string);

/**
 * @brief           Check S of srecord string
 * @param[in]       Srecord string
 * @param[out]      None
 * @param[inout]    None
 * @returns         Check 
 */
uint8_t check_S(uint8_t* str);

/**
 * @brief           Check S_Type of srecord string
 * @param[in]       Srecord string
 * @param[out]      None
 * @param[inout]    None
 * @returns         Check 
 */
uint8_t check_Type(uint8_t* str);

/**
 * @brief           Calculate Byte Count value of Srecord string
 * @param[in]       Srecord string
 * @param[out]      None
 * @param[inout]    None
 * @returns         Byte Count 
 */
uint8_t Byte_Count(uint8_t string[]);

/**
 * @brief           Calculate S_type value of Srecord string
 * @param[in]       Srecord string
 * @param[out]      None
 * @param[inout]    None
 * @returns         S_Type
 */
uint8_t S_Type(uint8_t* str);

/**
 * @brief           Check Byte Count of srecord string
 * @param[in]       Srecord string
 * @param[out]      None
 * @param[inout]    None
 * @returns         Check 
 */
uint8_t check_Byte_Count(uint8_t *str);

/**
 * @brief           Check Sum of srecord string
 * @param[in]       Srecord string
 * @param[out]      None
 * @param[inout]    None
 * @returns         Check 
 */
uint8_t check_Sum(uint8_t*str);

/**
 * @brief           Check Hexa  of srecord string, Characters in srecord
 *                  string in (1,9) or (A,F)
 * @param[in]       Srecord string
 * @param[out]      None
 * @param[inout]    None
 * @returns         Check 
 */
uint8_t check_Hexa (uint8_t *string );

/**
 * @brief           Free string
 * @param[in]       String , number of characters
 * @param[out]      None
 * @param[inout]    None
 * @returns         Node 
 */
void free_char(uint8_t *str_free,uint8_t size);

/**
 * @brief           Find max in 2 number
 * @param[in]       Number1, number2
 * @param[out]      None
 * @param[inout]    None
 * @returns         Max of 2 number 
 */
uint8_t max(uint8_t number1, uint8_t number2);

/**
 * @brief           Find max in 3 number
 * @param[in]       Number S1, number S2, number S3
 * @param[out]      None
 * @param[inout]    None
 * @returns         Max of 3 number 
 */
uint8_t Max_S(uint8_t S1,uint8_t S2, uint8_t S3 );

/**
 * @brief           Check ternimal of Srecord file
 * @param[in]       S_type of srecord data, S_type of count,
 *                  S_type of address start, Count of Srecord data
 * @param[out]      None
 * @param[inout]    None
 * @returns         Check 
 */
uint8_t checkS19_S28_S37(uint8_t check_max, uint8_t number2, uint8_t number3,
                         uint32_t count_Srec_Data) ;
/**
 * @brief           Read address and data fromm array
 * @param[in]       str: array of line
 *                  address, data
 * @param[out]      None
 * @param[inout]    None
 * @returns         None
 */
void Read_address_data(uint8_t*str , uint8_t *address, uint8_t *data);
#endif /* _SRECORD_H_ */
/*******************************************************************************
* End of file
*******************************************************************************/