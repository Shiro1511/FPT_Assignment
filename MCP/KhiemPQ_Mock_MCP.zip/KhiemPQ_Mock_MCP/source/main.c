/*******************************************************************************
* Include
*******************************************************************************/
#include <string.h>
#include "MKL46Z4.h"
#include "Queue_array.h"
#include "Srecord.h"
#include "Flash.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define GREEN_LED_ON      GPIOD->PCOR |= (1 << 5)
#define GREEN_LED_OFF     GPIOD->PSOR |= (1 << 5)
#define RED_LED_ON    GPIOE->PCOR |= (1 << 29)
#define RED_LED_OFF   GPIOE->PSOR |= (1 << 29)
/*******************************************************************************
* Variables
*******************************************************************************/
uint8_t queue_array[4][80];
uint8_t count = 0;
uint8_t array[80];
uint8_t address[8];
uint8_t data[64];
uint8_t queue_level = 0;
uint8_t queue_push = 0;
uint8_t queue_pop = 0;
uint8_t index_queue = 0;
/*******************************************************************************
* Function
*******************************************************************************/
void initLed()
{
    /* Enable clock for PORTD, PORTE */
    SIM->SCGC5 |= (1 << 12);    /* Set bit 12 */
    SIM->SCGC5 |= (1 << 13);    /* Set bit 13 */
    
    /* Configure multiplex of PTD5 and PTE29 as GPIO */
    PORTD->PCR[5] |= PORT_PCR_MUX(1);
    PORTE->PCR[29] |= PORT_PCR_MUX(1);
    
    /* Configure PTD5 and PTE29 as output */
    GPIOD->PDDR |= (1 << 5);
    GPIOE->PDDR |= (1 << 29);
    
    RED_LED_OFF;
    GREEN_LED_OFF;
}

void init_uart()
{
    /* Config clock source for UART0 as 20M */
    SIM->SOPT2 &= ~(1 <<16);
    SIM->SOPT2 |= (1 << 26);
    SIM->SOPT2 &= ~(1 << 27);
    
    /* Enable clock for uart0 */
    SIM->SCGC4 |= (1 <<10);
    
    /* Enable clock for port A */
    SIM->SCGC5 |= (1<<9);
    
    /* Config uart for pin PTA1, PTA2 */
    PORTA->PCR[1] = PORT_PCR_MUX(2);
    PORTA->PCR[2] = PORT_PCR_MUX(2);
    
    /* Receiver and transmitter use 8-bit or 9-bit data characters. */
    UART0->C4 &= ~(1<<5);
    
    /* Receiver and transmitter use 8-bit data characters */
    UART0->C1 &= ~(1<<4);
    
    /* No parity */
    UART0->C1 &= ~(1<<1);
    
    /* LSB fisrt */
    UART0->S2 &= ~(1<<5);
    
    /* Receive data not inverted */
    UART0->S2 &= ~(1<<4);
    
    /* Transmit data not inverted. */
    UART0->C3 &= ~(1<<4);
    
    /* Config baudrate UART0 as 9600 */
    UART0->C4 = 22;
    UART0->BDL = 95;
    
    /* Receiver Enable - Transmitter Enable */
    UART0->C2 |= 3 << 2;
    
    /* One stop bit */
    UART0->BDH &= ~(1<<5);
    
   /* Receiver Interrupt Enable for RDRF */
    UART0->C2 |= 1 << 5;
    
    NVIC_EnableIRQ(UART0_IRQn);
    
}

void send_message(char *data)
{
    while (*data != '\0')
    {
       UART0->D = *data;
       // while (UART0->S1 >> 7 == 0);
       while (UART0->S1 & 0x80 == 0x00);
       data++;
    }
    

}

void UART0_IRQHandler (void)
{
    uint8_t temp;


    temp = UART0->D;
    if(temp != '\0')
    {
        func_queue_push(queue_array, &queue_level,
                     &queue_push, temp, &index_queue);
    }
}
/*******************************************************************************
* Codes
*******************************************************************************/
int main()
{
    initLed();
    init_uart();
    
    while (1)
    {
        if(func_queue_empty(queue_level) != 0)
        {
            strcpy((char*) array, (const char *)func_queue_pop(queue_array, &queue_level, &queue_pop));
            if((check_S(array) & check_Type(array) & check_Byte_Count(array) & check_Sum(array) & check_Hexa(array)) == 1)
            {
                Read_address_data(array, address, data);
            }
            else
            {
                //RED_LED_ON;
                //send_message("ERROR");
            }
            free_char(address, 8);
            free_char(data, 64);
        }
          
    }
}